import pandas as pd

print("Integrantes del grupo 2")

datos = [
    {'Nombre':  'Angie', 'Edad': 23, 'Carrera': 'Ingenieria'},
    {'Nomb': 'Anny', 'Edad': 22, 'Carrera': 'Ingenieria'},
    {'Name': 'Aylin', 'Edad': 23, 'Carrera': 'Ingenieria'},
    {'Nombre': 'Jennifer', 'Edad': 23, 'Carrera': 'Ingenieria'},
    {'Nombre': 'Karla', 'Edad': 24, 'Carrera': 'Ingenieria'},
    {'Nombre': 'Adalid', 'Edad': 24, 'Carrera': 'Ingenieria'}
]

df = pd.DataFrame(datos)

print(df)