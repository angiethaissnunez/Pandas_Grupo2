import pandas as pd

datos = {
    'Nombre': ['Anny', 'Angie', 'Aylin', 'Jennifer', 'Karla', 'Adalid'],
    'Edad': ['22', '23', '23', '23', '24', '24'],
    'Carrera': ['Ingenieria', 'Ingenieria', 'Ingenieria', 'Ingenieria', 'Ingenieria', 'Ingenieria']

}

df = pd.DataFrame(datos)

print(df)